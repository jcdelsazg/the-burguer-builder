import React from 'react';

const UserOutput = (props) => {
    const outputComponent = {
        border: "1px solid green",
        margin: "15px auto",
        textAlign: "center",
        width: "200px"
    }

    return (
        <div style={outputComponent}>
            <span>{props.username}</span>
            <p className="p1">
                {props.text} 
            </p>
            <p className="p2">
                {props.text}
            </p>
        </div>
    );
}

export default UserOutput;