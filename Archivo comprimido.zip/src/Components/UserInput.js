import React, { Component } from 'react';
import './UserInput.css'

class UserInput extends Component {

    render(props) {
        
    return (
            <input 
                className='inputUser' 
                type="text" 
                onChange={this.props.changed} 
                value={this.props.username} 
            />);  
    }
}

export default UserInput;