import React, { Component } from 'react';
import './App.css';
import UserOutput from './Components/UserOutput'
import UserInput from './Components/UserInput'

class App extends Component {
  state = {
    username: "Paragraphs"
  };

  changeUsernameHandler = (event) => {
    const value = event.target.value;
    this.setState({ username: value });
  }
  
  render() {
    return (
      <div className="App">
          <UserInput 
            username={this.state.username}
            changed={this.changeUsernameHandler}
          />
          <UserOutput 
            text="I'm paragraph 1"
            username={this.state.username}
          />
          <UserOutput 
            text="I'm paragraph 2"
            username={this.state.username}
          />  
      </div>
    );
  }
}

export default App;
